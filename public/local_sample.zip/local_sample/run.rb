require "pp"
require "open3"

TEST_DATA = <<EOS
x01234567890x
0###########0
1S:#:::::# #1
2#:#:###:# #2
3#:::#:::# #3
4#####:### #4
5#:::::#   #5
6#:### # ###6
7#:::# # # #7
8###:### # #8
9#  :::::::G9
0###########0
x01234567890x
EOS

expected = TEST_DATA.each_line.map(&:chomp)[1 .. -2].map { |l|
  l[1 .. -2] + "\n"
}.join.chomp
stdin_data = expected.gsub(":", " ")
# stdout, status = *Open3.capture2("./solve.rb", stdin_data: stdin_data)
stdout, status = *Open3.capture2("ruby ./solve.rb", stdin_data: stdin_data)
stdout.gsub!(/((\r)?\n)*\z/m, "")

puts(<<EOS)
## input

#{stdin_data}

## output

#{stdout}

## result

#{(expected == stdout).inspect}
EOS
