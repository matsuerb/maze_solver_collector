maze_ary = STDIN.each_line.map(&:chomp)

# ここに処理を書いてください。

puts(maze_ary)
